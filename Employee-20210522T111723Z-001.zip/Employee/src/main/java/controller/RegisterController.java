package controller;


import java.sql.*;  
import java.util.ArrayList;  
import java.util.List;

import model.Register;  

public class RegisterController {
	
	public static Connection getConnection(){  
	    Connection con=null;  
	    try{  
	        Class.forName("com.mysql.jdbc.Driver");  
	        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/students","root","");  
	    }catch(Exception e){System.out.println(e);}  
	    return con;  
	}
	
    public static int save(Register reg){  
        int status=0;  
        try{  
            Connection con=RegisterController.getConnection();  
            PreparedStatement sql=con.prepareStatement(  
                         "insert into register(first_name,last_name,email,password) values (?,?,?,?)");  
            sql.setString(1,reg.getFirstname());  
            sql.setString(2,reg.getLastname());  
            sql.setString(3,reg.getEmail());  
            sql.setString(4,reg.getPassword());  
              
            status=sql.executeUpdate();         
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
        return status;  
    }

    public static int login(String email, String password)
    {
    int status = 0;
   
    try{  
    	 String dbemail,dbpassword;
        Connection con=RegisterController.getConnection();  
        PreparedStatement sql=con.prepareStatement("select email,password from register where email = ? AND password=?");   
        sql.setString(1, email);
        sql.setString(2, password);  
        ResultSet rs = sql.executeQuery();
        if (rs.next()) {
            dbemail = rs.getString("email");
            dbpassword = rs.getString("password");
            if(email.equals(dbemail) && password.equals(dbpassword))
            {
            	status = 1;
            }
        } else {
           status = 0;
        }
        con.close();  
    }catch(Exception ex){ex.printStackTrace();}  
    return status;  
}
    
}
