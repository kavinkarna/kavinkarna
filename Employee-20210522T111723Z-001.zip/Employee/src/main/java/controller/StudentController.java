package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.*;
import model.Student;
import java.sql.*;  

public class StudentController {

	public static Connection getConnection(){  
	    Connection con=null;  
	    try{  
	        Class.forName("com.mysql.jdbc.Driver");  
	        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/students","root","");  
	    }catch(Exception e){System.out.println(e);}  
	    return con;  
	}
	
    public static int save(Student reg){  
        int status=0;  
        try{  
            Connection con=StudentController.getConnection();  
            PreparedStatement sql=con.prepareStatement(  "insert into student(name,email,phone,dept,address) values (?,?,?,?,?)");  
            sql.setString(1,reg.getName());  
            sql.setString(2,reg.getEmail());  
            sql.setString(3,reg.getPhone());  
            sql.setString(4,reg.getDept());  
            sql.setString(5,reg.getAddress());  

            status=sql.executeUpdate();         
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
        return status;  
    }

    public static List<Student> view(){  
        List<Student> list=new ArrayList<Student>();  
          
        try{  
            Connection con=StudentController.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from student");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
                Student u=new Student();
                u.setId(rs.getInt("id"));
                u.setName(rs.getString("name"));  
                u.setEmail(rs.getString("email"));  
                u.setPhone(rs.getString("phone"));  
                u.setDept(rs.getString("dept")); 
                u.setAddress(rs.getString("address"));  
                list.add(u);  
            }  
        }catch(Exception e){System.out.println(e);}  
        return list;  
    }  
    public static Student viewOne(int id){  
        Student std=null;  
        try{  
            Connection con=StudentController.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from student where id=?");  
            ps.setInt(1,id);  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
                std=new Student();  
                std.setId(rs.getInt("id"));  
                std.setName(rs.getString("name"));  
                std.setEmail(rs.getString("email"));  
                std.setPhone(rs.getString("phone"));  
                std.setDept(rs.getString("dept"));  
                std.setAddress(rs.getString("address"));  
            }  
        }catch(Exception e){System.out.println(e);}  
        return std;  
    }  

    public static int update(Student std){  
        int status=0;  
        try{  
            Connection con=StudentController.getConnection();  
            PreparedStatement ps=con.prepareStatement("update student set name=?,email=?,phone=?,dept=?,address=? where id=?");  
            ps.setString(1,std.getName());  
            ps.setString(2,std.getEmail());  
            ps.setString(3,std.getPhone());  
            ps.setString(4,std.getDept());  
            ps.setString(5,std.getAddress());  
            ps.setInt(6,std.getId());  
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  

    public static int delete(int id){  
        int status=0;  
        try{  
            Connection con=getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from student  where id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
        }catch(Exception e){System.out.println(e);}  
      
        return status;  
    }  

    
}
