package webservlet;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import controller.RegisterController;
import model.Register;

public class AddRegister extends HttpServlet {


		public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException,ServletException
		{
			
			response.setContentType("text/html");
			PrintWriter out= response.getWriter();
			String first_name = request.getParameter("firstname");
			String last_name = request.getParameter("lastname");
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			
			 Register reg=new Register();  
		        reg.setFirstname(first_name);  
		        reg.setLastname(last_name);  
		        reg.setEmail(email);  
		        reg.setPassword(password); 
		        int s = RegisterController.save(reg);
		        if(s == 1)
		        {
//		        	out.print("<p>logged in successfully!</p>");  
//		        	request.getRequestDispatcher("/Student/viewStudents.jsp").include(request, response);  
		    		response.sendRedirect("/Employee/Student/viewStudents.jsp");
		        }
		        else {
		        	out.println("error");
		        }
	           
			}
		
}
