package webservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.StudentController;
import model.Student;

public class AddStudent extends HttpServlet {


	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException,ServletException
	{ 
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		String name = request.getParameter("name");
		String  email = request.getParameter("email");
		String  phone = request.getParameter("phone");
		String  dept = request.getParameter("dept");
		String  address = request.getParameter("address");
		 Student reg=new Student();  
	        reg.setName(name);  
	        reg.setEmail(email);  
	        reg.setPhone(phone);  
	        reg.setDept(dept); 
	        reg.setAddress(address); 
	        int s = StudentController.save(reg);
	        if(s != 0 )
	        {
	        	out.print("<p>Record saved successfully!</p>");  
	            request.getRequestDispatcher("/Student/viewStudents.jsp").include(request, response);  
	        }
	        else
	        {
	        	out.println("Error,No data added.");
	            request.getRequestDispatcher("/Student/viewStudents.jsp").include(request, response);  

	        }

	}

}
