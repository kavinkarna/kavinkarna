package webservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.RegisterController;
import model.Register;

public class Login extends HttpServlet{

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException,ServletException
	{
		
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
	        int s = RegisterController.login(email,password);
	        if(s == 1)
	        {
	            out.print("<p>logged in successfully!</p>");  
            request.getRequestDispatcher("/Student/viewStudents.jsp").include(request, response);  
	        }
	        else {
	        	out.println("error");
	        }
		}
	
}
